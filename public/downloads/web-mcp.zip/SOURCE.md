# Source & Attribution

- **Skill:** `web-mcp`
- **Directory:** `web-mcp`
- **Original source:** https://clawskills.sh/skills/slemo54-web-mcp
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/slemo54/web-mcp.md
- **Converted at:** 2026-10-31T22:15:01.076Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
