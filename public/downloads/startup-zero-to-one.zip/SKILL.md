---
name: startup-zero-to-one
description: Alias for raon-os — AI-powered startup companion for Korean founders. Install the main package for full functionality.
metadata: {"minis":{"originalSource":"https://clawskills.sh/skills/lifeissea-startup-zero-to-one","convertedAt":"2026-10-31T22:14:17.992Z","license":"Unknown"}}
---

# Startup 0→1 (Alias)

This is an alias package for **[raon-os](https://clawhub.com/skills/raon-os)**.

## Installation

```bash
clawhub install raon-os
```

All features (business plan evaluation, government funding matching, RAG pipeline, Kakao integration) are available in the `raon-os` package.

See [raon-os on ClawHub](https://clawhub.com/skills/raon-os) for full documentation.
