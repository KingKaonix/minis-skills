---
name: cls-news-scraper
description: "Use this skill to pull real-time market news from Cailian Press (CLS) and extract stock-positive catalysts."
metadata: {"minis":{"originalSource":"https://clawskills.sh/skills/ningjingzhiyuande-cls-news-scraper","convertedAt":"2026-10-31T22:10:18.362Z","license":"Unknown"}}
---

# cls-news-scraper

Use this skill to pull real-time market news from Cailian Press (CLS) and extract stock-positive catalysts.

## Inputs
- Time window (default: last 1 hour)
- Sector filter (default: 新能源, 消费)
- Event filter (default: 业绩预增, 重大合同, 政策扶持)

## Procedure
1. Collect latest CLS items from configured endpoint/source.
2. Normalize fields: title, summary, ticker, company, published_at, source_url.
3. Classify each item into event types.
4. Keep only matched industries and event types.
5. Output table rows for downstream scoring.

## Output Schema
- ticker
- company
- catalyst
- source_url
- timestamp
- confidence
