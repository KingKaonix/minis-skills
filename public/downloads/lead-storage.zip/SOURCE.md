# Source & Attribution

- **Skill:** `lead-storage`
- **Directory:** `lead-storage`
- **Original source:** https://clawskills.sh/skills/vishalgojha-lead-storage
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/vishalgojha/lead-storage.md
- **Converted at:** 2026-10-31T22:12:08.914Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
