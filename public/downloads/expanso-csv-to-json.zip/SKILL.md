---
name: expanso-csv-to-json
description: "\"Convert CSV data to JSON array of objects\". Use when the user needs expanso-csv-to-json functionality."
metadata: {"minis":{"originalSource":"https://clawskills.sh/skills/aronchick-expanso-csv-to-json","convertedAt":"2026-10-31T22:11:00.809Z","license":"Unknown"}}
---

# csv-to-json

"Convert CSV data to JSON array of objects"

## Requirements

- Expanso Edge installed (`expanso-edge` binary in PATH)
- Install via: `clawhub install expanso-edge`

## Usage

### CLI Pipeline
```bash
# Run standalone
echo '<input>' | expanso-edge run pipeline-cli.yaml
```

### MCP Pipeline
```bash
# Start as MCP server
expanso-edge run pipeline-mcp.yaml
```

### Deploy to Expanso Cloud
```bash
expanso-cli job deploy https://skills.expanso.io/csv-to-json/pipeline-cli.yaml
```

## Files

| File | Purpose |
|------|---------|
| `skill.yaml` | Skill metadata (inputs, outputs, credentials) |
| `pipeline-cli.yaml` | Standalone CLI pipeline |
| `pipeline-mcp.yaml` | MCP server pipeline |
