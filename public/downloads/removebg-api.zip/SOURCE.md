# Source & Attribution

- **Skill:** `removebg-api`
- **Directory:** `removebg-api`
- **Original source:** https://clawskills.sh/skills/rolandkakonyi-removebg-api
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/rolandkakonyi/removebg-api.md
- **Converted at:** 2026-10-31T22:13:35.445Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
