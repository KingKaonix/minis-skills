---
name: agent-autonomy-kit
version: 1.0.0
description: Stop waiting for prompts. Keep working.
homepage: https://github.com/itskai-dev/agent-autonomy-kit
metadata:
  openclaw:
    emoji: "🚀"
    category: productivity
  minis:
    originalSource: "https://clawskills.sh/skills/ryancampbell-agent-autonomy-kit"
    convertedAt: "2026-10-31T22:09:03.658Z"
    license: "Unknown"
---

# Agent Autonomy Kit

Transform your agent from reactive to proactive.

## Quick Start

1. Create `tasks/QUEUE.md` with Ready/In Progress/Blocked/Done sections
2. Update `HEARTBEAT.md` to pull from queue and do work
3. Set up cron jobs for overnight work and daily reports
4. Watch work happen without prompting

## Key Concepts

- **Task Queue** — Always have work ready
- **Proactive Heartbeat** — Do work, don't just check
- **Continuous Operation** — Work until limits hit

See README.md for full documentation.
