# Source & Attribution

- **Skill:** `publora-bluesky`
- **Directory:** `publora-bluesky`
- **Original source:** https://clawskills.sh/skills/sergebulaev-publora-bluesky
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/sergebulaev/publora-bluesky.md
- **Converted at:** 2026-10-31T22:13:25.383Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
