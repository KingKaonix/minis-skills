# Source & Attribution

- **Skill:** `flyworks-avatar-video`
- **Directory:** `flyworks-avatar-video`
- **Original source:** https://clawskills.sh/skills/linhui99-flyworks-avatar-video
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/linhui99/flyworks-avatar-video.md
- **Converted at:** 2026-10-31T22:11:13.068Z
- **License:** MIT

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
