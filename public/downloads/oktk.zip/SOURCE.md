# Source & Attribution

- **Skill:** `oktk`
- **Directory:** `oktk`
- **Original source:** https://clawskills.sh/skills/satnamra-oktk
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/satnamra/oktk.md
- **Converted at:** 2026-10-31T22:12:57.185Z
- **License:** MIT

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
