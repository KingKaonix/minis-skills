# Source & Attribution

- **Skill:** `codex-sub-agents-1`
- **Directory:** `codex-sub-agents-1`
- **Original source:** https://clawskills.sh/skills/phucanh08-codex-sub-agents-1
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/phucanh08/codex-sub-agents-1.md
- **Converted at:** 2026-10-31T22:10:20.679Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
