# Source & Attribution

- **Skill:** `skill-doctorbot-healthcheck-free`
- **Directory:** `skill-doctorbot-healthcheck-free`
- **Original source:** https://clawskills.sh/skills/bamontejano-skill-doctorbot-healthcheck-free
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/bamontejano/skill-doctorbot-healthcheck-free.md
- **Converted at:** 2026-10-31T22:13:59.352Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
