# Source & Attribution

- **Skill:** `cosyvoice3-macos`
- **Directory:** `cosyvoice3-macos`
- **Original source:** https://clawskills.sh/skills/lhuaizhong-cosyvoice3-macos
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/lhuaizhong/cosyvoice3-macos.md
- **Converted at:** 2026-10-31T22:10:28.799Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
