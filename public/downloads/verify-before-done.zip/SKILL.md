---
name: verify-before-done
description: Require fresh verification evidence before claiming work is complete. Use ALWAYS before any completion claim, commit, push, PR, or status report. Prevents false completion claims.
metadata:
  author: misskim
  version: "1.0"
  origin: Concept from obra/superpowers verification-before-completion
  minis:
    originalSource: "https://clawskills.sh/skills/kjaylee-verify-before-done"
    convertedAt: "2026-10-31T22:14:52.551Z"
    license: "Unknown"
---

# Verify Before Done

## 철칙

```
검증 증거 없이 완료 주장 절대 금지
```

## 게이트 함수

모든 완료/성공 주장 전에:

1. **식별:** 이 주장을 증명하는 명령은?
2. **실행:** 해당 명령을 지금 실행 (이전 결과 불가)
3. **읽기:** 전체 출력, exit code, 실패 수 확인
4. **검증:** 출력이 주장을 확인하는가?
   - No → 실제 상태를 증거와 함께 보고
   - Yes → 증거와 함께 완료 주장
5. **그 후에만 주장 가능**

## 주장별 필요 증거

| 주장 | 필요한 증거 | 불충분한 증거 |
|------|------------|-------------|
| "테스트 통과" | 테스트 명령 출력: 0 failures | 이전 실행, "통과할 것" |
| "린터 깨끗" | 린터 출력: 0 errors | 부분 체크, 추정 |
| "빌드 성공" | 빌드 명령: exit 0 | 린터 통과, 로그가 괜찮아 보임 |
| "버그 수정됨" | 원래 증상 테스트: 통과 | 코드 변경함, 수정 추정 |
| "요구사항 충족" | 항목별 체크리스트 | 테스트 통과 |

## 🚨 위험 단어 (사용 시 즉시 멈춤)

이 단어들이 입에서 나오려 하면 **STOP:**
- "~될 거야" / "~할 것 같아"
- "아마" / "대체로"
- "좋아!" / "완벽!" / "끝!"  (검증 전)
- "~한 것 같은데"
- "수동으로 확인했으니"
- "에이전트가 성공이라고 했으니"

## 위임 작업도 예외 없음

서브에이전트가 "성공" 보고 → **독립 검증 필수**
- VCS diff 확인 → 변경 사항 실제로 있는지?
- 테스트 직접 실행 → 정말 통과하는지?
- 에이전트 보고를 맹신하지 말 것

## 합리화 방지

| 핑계 | 현실 |
|------|------|
| "지금 잘 작동할 거야" | 검증 실행하세요 |
| "확신해" | 확신 ≠ 증거 |
| "이번 한 번만" | 예외 없음 |
| "린터 통과했으니" | 린터 ≠ 컴파일러 ≠ 런타임 |
| "피곤해" | 피곤함 ≠ 면제 |
| "부분 확인이면 충분" | 부분 확인은 아무것도 증명 못함 |

## 왜 중요한가

검증 없는 완료 주장은:
- 신뢰를 깨뜨림
- undefined 함수가 배포됨
- 요구사항 누락이 발견 안 됨
- 거짓 완료 → 재작업 → 시간 낭비

**검증은 선택이 아니라 필수.**
