# Source & Attribution

- **Skill:** `baidu-baike`
- **Directory:** `baidu-baike`
- **Original source:** https://clawskills.sh/skills/jlpjavawayup-baidu-baike
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/jlpjavawayup/baidu-baike.md
- **Converted at:** 2026-10-31T22:09:44.209Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
