# Source & Attribution

- **Skill:** `self-evolve`
- **Directory:** `self-evolve`
- **Original source:** https://clawskills.sh/skills/be1human-self-evolve
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/be1human/self-evolve.md
- **Converted at:** 2026-10-31T22:13:50.144Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
