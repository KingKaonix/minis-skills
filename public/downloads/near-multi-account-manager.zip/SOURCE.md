# Source & Attribution

- **Skill:** `near-multi-account-manager`
- **Directory:** `near-multi-account-manager`
- **Original source:** https://clawskills.sh/skills/shaiss-near-multi-account-manager
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/shaiss/near-multi-account-manager.md
- **Converted at:** 2026-10-31T22:12:48.672Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
