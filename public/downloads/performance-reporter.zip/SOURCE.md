# Source & Attribution

- **Skill:** `performance-reporter`
- **Directory:** `performance-reporter`
- **Original source:** https://clawskills.sh/skills/aaron-he-zhu-performance-reporter
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/aaron-he-zhu/performance-reporter.md
- **Converted at:** 2026-10-31T22:13:10.374Z
- **License:** Apache-2.0

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
