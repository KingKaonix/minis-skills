---
name: expanso-log-sanitize
description: "\"Sanitize log entries by removing passwords, tokens, and sensitive patterns\". Use when the user needs expanso-log-sanitize functionality."
metadata: {"minis":{"originalSource":"https://clawskills.sh/skills/aronchick-expanso-log-sanitize","convertedAt":"2026-10-31T22:11:01.480Z","license":"Unknown"}}
---

# log-sanitize

"Sanitize log entries by removing passwords, tokens, and sensitive patterns"

## Requirements

- Expanso Edge installed (`expanso-edge` binary in PATH)
- Install via: `clawhub install expanso-edge`

## Usage

### CLI Pipeline
```bash
# Run standalone
echo '<input>' | expanso-edge run pipeline-cli.yaml
```

### MCP Pipeline
```bash
# Start as MCP server
expanso-edge run pipeline-mcp.yaml
```

### Deploy to Expanso Cloud
```bash
expanso-cli job deploy https://skills.expanso.io/log-sanitize/pipeline-cli.yaml
```

## Files

| File | Purpose |
|------|---------|
| `skill.yaml` | Skill metadata (inputs, outputs, credentials) |
| `pipeline-cli.yaml` | Standalone CLI pipeline |
| `pipeline-mcp.yaml` | MCP server pipeline |
