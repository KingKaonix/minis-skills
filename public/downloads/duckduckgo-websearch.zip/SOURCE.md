# Source & Attribution

- **Skill:** `duckduckgo-websearch`
- **Directory:** `duckduckgo-websearch`
- **Original source:** https://clawskills.sh/skills/ianwchoi-duckduckgo-websearch
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/ianwchoi/duckduckgo-websearch.md
- **Converted at:** 2026-10-31T22:10:49.098Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
