# Source & Attribution

- **Skill:** `finance-search-agent-strategy`
- **Directory:** `finance-search-agent-strategy`
- **Original source:** https://clawskills.sh/skills/sophiaashi-finance-search-agent-strategy
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/sophiaashi/finance-search-agent-strategy.md
- **Converted at:** 2026-10-31T22:11:08.986Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
