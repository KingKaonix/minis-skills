# Source & Attribution

- **Skill:** `sovereign-brand-voice-writer`
- **Directory:** `sovereign-brand-voice-writer`
- **Original source:** https://clawskills.sh/skills/ryudi84-sovereign-brand-voice-writer
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/ryudi84/sovereign-brand-voice-writer.md
- **Converted at:** 2026-10-31T22:14:12.848Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
