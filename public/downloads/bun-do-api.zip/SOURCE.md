# Source & Attribution

- **Skill:** `bun-do-api`
- **Directory:** `bun-do-api`
- **Original source:** https://clawskills.sh/skills/ricardofrantz-bun-do-api
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/ricardofrantz/bun-do-api.md
- **Converted at:** 2026-10-31T22:09:58.757Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
