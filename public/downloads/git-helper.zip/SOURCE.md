# Source & Attribution

- **Skill:** `git-helper`
- **Directory:** `git-helper`
- **Original source:** https://clawskills.sh/skills/xejrax-git-helper
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/xejrax/git-helper.md
- **Converted at:** 2026-10-31T22:11:25.696Z
- **License:** Unknown

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
