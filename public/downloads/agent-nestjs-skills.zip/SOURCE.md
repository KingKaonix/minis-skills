# Source & Attribution

- **Skill:** `agent-nestjs-skills`
- **Directory:** `agent-nestjs-skills`
- **Original source:** https://clawskills.sh/skills/tuanvidev-agent-nestjs-skills
- **Markdown endpoint:** https://clawskills.sh/skills-markdown/tuanvidev/agent-nestjs-skills.md
- **Converted at:** 2026-10-31T22:09:07.317Z
- **License:** MIT

## Conversion notes

This package was converted from the publicly listed skill page above.
Only `SKILL.md` was available from the markdown endpoint at conversion time;
bundled scripts, references, and other assets referenced by the skill may not
be included. No secrets are included.

Attribution is retained here inside the package. The catalog website does not
link to the original source.
