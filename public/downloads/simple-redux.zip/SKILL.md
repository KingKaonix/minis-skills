---
name: simple-redux
description: Formats text according to specified style guidelines. A clean example skill with no security issues.
license: MIT
metadata: {"minis":{"originalSource":"https://clawskills.sh/skills/tjade273-simple-redux","convertedAt":"2026-10-31T22:13:57.847Z","license":"MIT"}}
---

# Simple Text Formatter

This skill formats text according to style guidelines.

## Features

- Capitalize sentences
- Fix spacing
- Apply punctuation rules

## Usage

When the user provides text to format, apply the following rules:
1. Capitalize first letter of sentences
2. Ensure single space after periods
3. Remove trailing whitespace

In most cases, you should use the python tool in `scripts/formatter.py` rather
than attempting the conversion yourself.

## Example

Input: "hello world.this is a test."
Output: "Hello world. This is a test."
